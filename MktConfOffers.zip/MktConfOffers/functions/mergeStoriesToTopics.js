return agile.mergeStoriesToTopics(req);   // requires library, supplied on request.
