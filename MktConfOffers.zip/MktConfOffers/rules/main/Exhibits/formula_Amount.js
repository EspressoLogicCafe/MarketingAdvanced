return row.Cost * row.Quantity;
