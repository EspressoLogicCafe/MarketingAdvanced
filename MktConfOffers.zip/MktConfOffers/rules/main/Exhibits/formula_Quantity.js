if (row.Quantity === null)
    return 1;
else
    return row.Quantity;
