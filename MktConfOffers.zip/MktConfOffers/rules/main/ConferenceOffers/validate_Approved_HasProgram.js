if (row.Approved === true && row.MarketingProgram === null) 
    return false;
 else 
    return true;
