return (row.Budget >= (row.ExhibitsCost + row.TalksCost));
