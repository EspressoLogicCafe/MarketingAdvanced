var Conf = {    // preferably, load values from property files, as in MktMgmt
    acctgURL: 'http://localhost:8080/rest/default/MktMgmt/v1/ProcessCharges',
    acctgAuth: { headers: { Authorization: "CALiveAPICreator AcctgToken:1" }}
};
