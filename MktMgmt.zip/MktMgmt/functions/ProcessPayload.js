row.ProcessedStatus = "processed: " + new Date(); // set table row attribute; starts update processing
return {statusCode: 201};
